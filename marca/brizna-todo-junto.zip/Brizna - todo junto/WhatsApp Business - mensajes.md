# WhatsApp Business para Brizna: que se conteste casi solo

**Para qué sirve:** cuando alguien pulse *Pedir* en la web, le llegará a Adriana un mensaje ya escrito con el producto. Con esta configuración, Adriana contesta con **un solo toque** y el cliente siempre sabe cómo va su pedido.

> Importante: que WhatsApp avise **solo y sin que Adriana toque nada** cada vez que cambia el estado del pedido necesita la versión de pago para empresas grandes (WhatsApp Business API). Para un negocio pequeño no compensa. Lo de abajo es gratis y lo más parecido: un toque y listo.

## 1. Instalar la app gratuita (una vez)

1. En el móvil de Adriana: descargar **WhatsApp Business** (la app verde con una "B"; es gratis).
2. Registrarla con el número de Brizna. Lo ideal es un número solo para el negocio. Si usa su número de siempre, la app Business también sirve.
3. Poner el **nombre del negocio**: Brizna. Foto de perfil: el logo. Descripción corta: *Jabones y sales artesanales hechos a mano*.

## 2. Mensajes automáticos (se configuran una vez)

En WhatsApp Business: **Ajustes → Herramientas para la empresa**.

**Mensaje de bienvenida** (se envía solo cuando alguien escribe por primera vez):
> ¡Hola! Gracias por escribir a Brizna. Ya he recibido tu mensaje y te respondo en cuanto pueda. Hago todo a mano, así que puede tardar un poquito.

**Mensaje de ausencia** (se envía solo fuera de tu horario):
> ¡Hola! Ahora mismo no estoy, pero he recibido tu pedido. Te contesto en cuanto vuelva.

## 3. Respuestas rápidas (el truco)

En **Herramientas para la empresa → Respuestas rápidas** crea estas. Luego, en cualquier chat, Adriana escribe `/` y elige la que quiera: se rellena sola.

| Atajo | Mensaje |
|---|---|
| `/recibido` | ¡Gracias por tu pedido! Lo tengo anotado. ¿Lo recoges o te lo envío? Si es envío, dime tu dirección. |
| `/proceso` | Tu pedido ya está **en proceso**: lo estoy preparando a mano. Te aviso en cuanto esté listo. |
| `/listo` | ¡Tu pedido está **listo**! Dime cuándo te viene bien recogerlo o cuándo te lo envío. |
| `/enviado` | Tu pedido ya va de camino. En cuanto llegue, cuéntame qué te ha parecido. ¡Gracias! |
| `/precio` | El precio es: [PRECIO]. Si quieres, te lo reservo ahora. |
| `/agotado` | Ahora mismo no lo tengo, pero lo estoy preparando. Te aviso cuando esté disponible. |

(Cambiar los textos por las palabras de Adriana: tienen que sonar a ella.)

## 4. Etiquetas para no perderse

En WhatsApp Business se pueden poner **etiquetas de colores** a cada chat. Crear cuatro: **Nuevo pedido**, **En proceso**, **Listo**, **Entregado**. Al cambiar un pedido de estado, cambia la etiqueta y manda la respuesta rápida. Así, de un vistazo, ve qué tiene pendiente.

## 5. Opcional: catálogo en WhatsApp

La misma app permite crear un **Catálogo** con foto, nombre y precio de cada producto. Es un extra: la web ya hace ese trabajo.
